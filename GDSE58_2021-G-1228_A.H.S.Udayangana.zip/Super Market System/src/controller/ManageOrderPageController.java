package controller;

public class ManageOrderPageController {
}
